package com.googlecode.android_scripting.facade;

interface JpegProvider {
  public byte[] getJpeg();
}