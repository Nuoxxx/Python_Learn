from distutils.core import setup

setup(
    name        = 'nesteramy',
    version     = '1.0.3',
    py_module   =['nesteramy'],
    author      = 'xuxuexia',
    author_email= 'yesiwillbethere@126.com',
    url         = 'http://www.headfirstlabs.com',
    description = 'Add end',
)
